import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import MainPage from "../MainPage";

test("renders main page heading", () => {
  render(
    <BrowserRouter>
      <MainPage />
    </BrowserRouter>
  );

  const heading = screen.getByText(/posts/i);
  expect(heading).toBeInTheDocument();
});
