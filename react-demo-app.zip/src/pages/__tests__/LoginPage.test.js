import { render, screen, fireEvent } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import LoginPage from "../LoginPage";


test("renders login form and validates input", () => {
  render(
    <BrowserRouter>
      <LoginPage />
    </BrowserRouter>
  );

  const input = screen.getByLabelText(/phone number/i);
  const button = screen.getByRole("button", { name: /login/i });

  // Input and button should exist
  expect(input).toBeInTheDocument();
  expect(button).toBeInTheDocument();

  // Type invalid number and submit
  fireEvent.change(input, { target: { value: "0712345678" } });
  fireEvent.click(button);

  // Error message should appear
  expect(screen.getByText(/must start with/i)).toBeInTheDocument();
});
