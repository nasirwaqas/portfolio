import { render, screen } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import DetailPage from "../DetailPage";


test("renders loading text initially", () => {
  render(
    <MemoryRouter initialEntries={["/detail/1"]}>
      <Routes>
        <Route path="/detail/:id" element={<DetailPage />} />
      </Routes>
    </MemoryRouter>
  );

  expect(screen.getByText(/loading/i)).toBeInTheDocument();
});
